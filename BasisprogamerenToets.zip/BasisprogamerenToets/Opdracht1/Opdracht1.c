#include <stdio.h>

void main() {
	double a, b, c;
	printf("Geef 3 ints: a, b, c: ");
	scanf_s("%lf, %lf, %lf", &a, &b, &c);
	printf("Het antwoord is: %lf", a * b * c);

	
}